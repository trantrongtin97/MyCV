const images = {
    avatar : require('./avatar.jpg'),
}

export default images;