import routesConfig from "../configs/route";
import Profile from "../pages/profile";

const publicRoutes = [
    {path : routesConfig.profile, component : Profile}
]; // cac router ko can dang nhap van vao dc

const privateRoutes = [
    
]; // cac router phai dang nhap van vao dc

export {publicRoutes, privateRoutes} 