const routes = {
    profile : '/',
    professionalSummary : '/pfs',
    education : '/edu',
    workexperience : '/work-exp',
    technology : '/tech',
    projects : '/projects'
}
export default routes;