import { Fragment } from 'react';
import styles from './SideBar.module.scss';
import classNames from 'classnames/bind';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faLinkedin,faFacebookF, faGithub,faInstagram} from '@fortawesome/free-brands-svg-icons';

const cx = classNames.bind(styles)

const Sidebar = () => {
    return (
        <Fragment>
            <div className={cx('logo')}>
                <a href="index.html">
                    <span>My</span>
                    <span>Resume</span>
                </a>
            </div>
            <div className={cx('nav')}>
                <ul>
                    <li><a href="pfs.html">Professional Summary</a></li>
                    <li><a href="edu.html">Education</a></li>
                    <li><a href="work-exp.html">Work Experience</a></li>
                    <li><a href="tech.html">Technology And Skills</a></li>
                    <li><a href="proj.html">Projects</a></li>
                </ul>
            </div>
            <div className={cx('left-footer')}>
                <div className={cx('social-icons')}>
                    <ul>
                        <li><a href=""><FontAwesomeIcon className={cx('i-primary')} icon={faLinkedin} /></a></li>
                        <li><a href=""><FontAwesomeIcon className={cx('i-primary')}  icon={faFacebookF} /></a></li>
                        <li><a href=""><FontAwesomeIcon className={cx('i-primary')}  icon={faGithub} /></a></li>
                        <li><a href=""><FontAwesomeIcon className={cx('i-primary')}  icon={faInstagram} /></a></li>
                    </ul>
                </div>
                <div className={cx('foot-contact')}>
                    <ul>
                        <li>trantrongtin97@gmail.com</li>
                        <li>0902412793</li>
                    </ul>
                </div>
            </div>
        </Fragment>
    );
}

export default Sidebar;